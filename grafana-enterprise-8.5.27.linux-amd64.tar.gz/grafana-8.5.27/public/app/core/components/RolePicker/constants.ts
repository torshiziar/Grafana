export const MENU_MAX_HEIGHT = 300; // max height for the picker's dropdown menu
